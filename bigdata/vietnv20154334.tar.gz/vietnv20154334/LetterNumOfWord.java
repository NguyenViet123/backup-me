package letterNoW;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;

import java.io.File;
import java.util.Arrays;

public class LetterNumOfWord {

    SparkConf conf = new SparkConf().setAppName("Letter_Num of Work").setMaster("local[2]")
            .set("spark.executor.memory", "2g");
    JavaSparkContext sc = new JavaSparkContext(conf);

    public static void main(String[] args) {
        LetterNumOfWord letterNumOfWord = new LetterNumOfWord();

//        System.out.println(path);
        JavaPairRDD<Character, Integer> result =
                letterNumOfWord.compute("hdfs:/user/viet-user/dataWords.txt");


        result.saveAsTextFile("file:///home/viet-user/Desktop/CountLetter.txt");
    }

    public JavaPairRDD<Character, Integer> compute(String path) {

        JavaRDD<String> textFile = sc.textFile(path);

        return textFile.flatMap(s -> {
            return Arrays.asList(s.toLowerCase().split(" ")).iterator();
        }).mapToPair(s1 -> {
            System.out.println("====" + s1);
            if (s1 != ""){
                return new Tuple2<>(s1.charAt(0), 1);
            }
            return null;
        }).reduceByKey((a, b) -> a + b);

    }



}
